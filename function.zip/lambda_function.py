import boto3
import json
import os

s3 = boto3.client('s3')

def lambda_handler(event, context):
    try:
        print("Lambda function triggered!")
        for record in event['Records']:
            bucket_name = record['s3']['bucket']['name']
            file_key = record['s3']['object']['key']
            
            print(f"Processing file: {file_key} from bucket: {bucket_name}")
            
            # Get the file from S3
            response = s3.get_object(Bucket=bucket_name, Key=file_key)
            file_content = response['Body'].read().decode('utf-8')
            
            # Here, you can add further processing like inserting data into RDS
            print(f"File content: {file_content}")
            
        return {
            'statusCode': 200,
            'body': json.dumps('File processed successfully!')
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps('File processing failed.')
        }
